package testrunner;

import page.LoginPage;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;
import setup.Setup;

public class LoginTestRunner extends Setup {
    LoginPage loginPage;
    @Test(priority = 1)
    public void doLoginWithWrongCreds(){
    loginPage=new LoginPage(driver);
    loginPage.doLogin("Admin", "admin1234");
        String messageActual= driver.findElement(By.className("oxd-alert-content-text")).getText();
        String messageExpected="Invalid credentials";
        Assert.assertEquals(messageActual,messageExpected);
    }
    @Test(priority = 2, groups = "smoke")
    public void doLogin(){
        loginPage=new LoginPage(driver);
        loginPage.doLogin("Admin", "admin123");
    }
}
