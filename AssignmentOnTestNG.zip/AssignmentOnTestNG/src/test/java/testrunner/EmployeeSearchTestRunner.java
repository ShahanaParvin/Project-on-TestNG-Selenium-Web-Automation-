package testrunner;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import page.LoginPage;
import com.github.javafaker.Faker;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import page.SearchEmployee;
import setup.Setup;
import utils.Utils;

import java.io.IOException;

public class EmployeeSearchTestRunner extends Setup {
    LoginPage loginPage;

    //@BeforeClass(groups = "smoke")
    @Test(priority = 1, description = "Employee successfully", groups = "smoke")
    public void doLogin() {
        loginPage = new LoginPage(driver);
        loginPage.doLogin("Admin", "admin123");
    }

    @Test(priority = 2)
    public void WrongEmployeeSearchName() {
        SearchEmployee empSearch = new SearchEmployee(driver);
        empSearch.directoryField.get(8).click();
        Faker faker = new Faker();
        String wrongEmployeeName = faker.name().firstName();
        empSearch.employeeName.get(1).sendKeys(wrongEmployeeName);
//        driver.findElement(By.tagName("input")).sendKeys(wrongEmployeeName);
        empSearch.employeeSearch.get(1).click();
        String titleActual=driver.findElements(By.className("oxd-text--span")).get(12).getText();
        String titleExpected = "Invalid";
        Assert.assertTrue(titleActual.contains(titleExpected));
    }

    @Test(priority = 3, groups = "smoke")
    public void searchEmployeeName() throws InterruptedException, IOException, ParseException {
        SearchEmployee empSearch=new SearchEmployee(driver);
        empSearch.directoryField.get(8).click();

        JSONArray empArray=Utils.readJsonArray("./src/test/resources/employees.json");
        JSONObject empObject= (JSONObject) empArray.get(empArray.size()-1);
        empSearch.employeeName.get(1).sendKeys(empObject.get("firstname").toString());
        Thread.sleep(3000);

        Actions action=new Actions(driver);
        action.sendKeys(Keys.ARROW_DOWN).perform();
        action.sendKeys(Keys.ENTER).perform();
        empSearch.employeeName.get(1).getText();
        empSearch.employeeSearch.get(1).click();
        Thread.sleep(3000);
//        String titleActual=driver.findElements(By.className("oxd-text--span")).get(12).getText();
//        String titleExpected="(1) Record Found";
//        Assert.assertTrue(titleActual.contains(titleExpected));
     //   Assert.assertEquals(titleActual,titleExpected);
      //  JSONArray empArray= utils.Utils.readJsonArray("./src/test/resources/employees.json");
     //   driver.findElement(By.name("oxd-autocomplete-text-input")).sendKeys("Bernardo Skiles");
    }
    @Test(priority = 4)
    public void wrongSearchByEmployeeId() throws InterruptedException {
        SearchEmployee empSearch = new SearchEmployee(driver);
        empSearch.directoryField.get(8).click();
        Faker faker = new Faker();
        String wrongEmployeeId = faker.idNumber().toString();
        empSearch.employeeName.get(1).sendKeys(wrongEmployeeId);
        empSearch.employeeSearch.get(1).click();
        Thread.sleep(3000);
        String titleActual=driver.findElements(By.className("oxd-text--span")).get(12).getText();
        String titleExpected = "Invalid";
        Assert.assertTrue(titleActual.contains(titleExpected));
    }

    @Test(priority = 5, groups = "smoke")
    public void searchByEmployeeId() throws IOException, ParseException, InterruptedException {
        SearchEmployee empSearch=new SearchEmployee(driver);
        empSearch.directoryField.get(8).click();

        JSONArray empArray= Utils.readJsonArray("./src/test/resources/employees.json");
        JSONObject empObject= (JSONObject) empArray.get(empArray.size()-1);
        empSearch.employeeName.get(1).sendKeys(empObject.get("employeeid").toString());
        Thread.sleep(3000);

        Actions action=new Actions(driver);
        action.sendKeys(Keys.ARROW_DOWN).perform();
        action.sendKeys(Keys.ENTER).perform();
        empSearch.employeeName.get(1).getText();
        empSearch.employeeSearch.get(1).click();
        Thread.sleep(3000);
    }
    @Test(priority = 6, groups = "smoke")
    public void logout(){
        loginPage.lblProfileName.click();
        loginPage.linkLogout.get(3).click();
    }
}
