package testrunner;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import page.LoginPage;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.annotations.Test;
import page.MyInfo;
import setup.Setup;
import utils.Utils;

import java.io.IOException;

public class NewUserTestRunner extends Setup {
    LoginPage loginPage;

    @Test(priority = 1, description = "New employee can login successfully", groups = "smoke")
    public void doLogin() throws IOException, ParseException {
        loginPage=new LoginPage(driver);
        JSONArray empArray= Utils.readJsonArray("./src/test/resources/employees.json");
        JSONObject empObject= (JSONObject) empArray.get(empArray.size()-1);
        loginPage.doLogin(empObject.get("username").toString(),empObject.get("password").toString());
    }

    @Test(priority = 2, groups = "smoke")
    public void Gender() throws InterruptedException {
        MyInfo myInfo=new MyInfo(driver);
        myInfo.menu.get(2).click();
        Thread.sleep(3000);
        myInfo.gender.get(1).click();
        Thread.sleep(3000);
        myInfo.save.get(1).click();
        Thread.sleep(3000);
    }

    @Test(priority = 3, groups = "smoke")
    public void bloodGroup() throws InterruptedException {
        MyInfo myInfo=new MyInfo(driver);
        Actions action=new Actions(driver);
        action.click(myInfo.bloodgroup.get(2));
        Thread.sleep(3000);
        action.sendKeys(Keys.ARROW_DOWN).perform();
        action.sendKeys(Keys.ARROW_DOWN).perform();
        action.sendKeys(Keys.ARROW_DOWN).perform();
        action.sendKeys(Keys.ARROW_DOWN).perform();
        action.sendKeys(Keys.ARROW_DOWN).perform();
        action.sendKeys(Keys.ARROW_DOWN).perform();
        action.sendKeys(Keys.ARROW_DOWN).perform();
        action.sendKeys(Keys.ARROW_DOWN).perform();
        action.sendKeys(Keys.ENTER).perform();
        myInfo.bloodtype.get(2).getText();
        Thread.sleep(3000);
        myInfo.save.get(1).click();
        Thread.sleep(3000);
    }
    @Test(priority = 3, groups = "smoke")
    public void logout(){
        LoginPage loginPage=new LoginPage(driver);
        loginPage.lblProfileName.click();
        loginPage.linkLogout.get(3).click();
    }
}
