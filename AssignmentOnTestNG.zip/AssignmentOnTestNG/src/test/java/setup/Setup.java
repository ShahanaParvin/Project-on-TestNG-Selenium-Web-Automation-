package setup;

import org.testng.annotations.*;
import page.LoginPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;

public class Setup {
    public WebDriver driver;
    @BeforeClass(groups = "smoke")
    public void setup() {
       driver=new ChromeDriver();
       driver.manage().window().maximize();
       driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
       driver.get("https://opensource-demo.orangehrmlive.com/");
    }
    @AfterClass(groups = "smoke")
    public void close() {
//        LoginPage loginPage=new LoginPage(driver);
//        loginPage.logout();
     //   driver.quit();
    }
}
