package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeTest;

import java.util.List;

public class SearchEmployee {
    @FindBy(className = "oxd-main-menu-item")
    public
    List<WebElement> directoryField;
    @FindBy(tagName = "input")
    public
    List<WebElement> employeeName;
    @FindBy(className="oxd-button")
    public
    List<WebElement> employeeSearch;

    public SearchEmployee(WebDriver driver){
        PageFactory.initElements(driver,this);
    }
}
