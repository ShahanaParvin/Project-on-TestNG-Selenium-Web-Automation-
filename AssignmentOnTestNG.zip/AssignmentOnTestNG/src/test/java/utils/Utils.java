package utils;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import page.EmployeeModel;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class Utils {
    public static void main(String[] args) throws IOException, ParseException {
        String password= generateRandomPassword(12);
    //    System.out.println(password);
        JSONArray empArray= readJsonArray("./src/test/resources/employees.json");
        JSONObject jsonObject= (JSONObject) empArray.get(0);
        System.out.println(jsonObject.get("username"));
      //  System.out.println(jsonObject.get("password"));
        System.out.println(jsonObject.get("employeeid"));
    }

    public static String generateRandomPassword(int len){
        String chars="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghi"+"jklmnopqrstuvwxyz!@#$%&";
        Random rnd = new Random();
        StringBuilder sb = new StringBuilder(len);
        for (int i = 0; i < len; i++){
            sb.append(chars.charAt(rnd.nextInt(chars.length())));
        }
            return sb.toString();
    }

    public static void saveInfo(EmployeeModel model) throws IOException, ParseException {
        String fileUrl="./src/test/resources/employees.json";
        JSONParser jsonParser=new JSONParser();
        JSONArray jsonArray= (JSONArray) jsonParser.parse(new FileReader(fileUrl));
        JSONObject empobj=new JSONObject();
        empobj.put("firstname",model.getFirstname());
        empobj.put("lastname",model.getLastname());
        empobj.put("username",model.getUsername());
        empobj.put("password",model.getPassword());
        empobj.put("employeeid", model.getEmployeeid());

        jsonArray.add(empobj);
        System.out.println(jsonArray);

        FileWriter writer=new FileWriter(fileUrl);
        writer.write(jsonArray.toJSONString());
        writer.flush();
        writer.close();
    }
    public static JSONArray readJsonArray(String filePath) throws IOException, ParseException {
        JSONParser parser=new JSONParser();
        JSONArray jsonArray= (JSONArray) parser.parse(new FileReader(filePath));
        return jsonArray;
    }
}
